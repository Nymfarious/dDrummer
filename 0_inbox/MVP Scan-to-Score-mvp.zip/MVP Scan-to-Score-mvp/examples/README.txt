Drop example PDFs or images here for local testing.
