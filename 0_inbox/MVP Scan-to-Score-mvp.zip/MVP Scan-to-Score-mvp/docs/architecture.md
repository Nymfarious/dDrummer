
# Architecture (MVP)

```text
[ Browser: web-ui ] --HTTP--> [ omr-service ] --(OMR/Audiveris)--> MusicXML
          |                                   ^
          |                                   |
   OSMD/Verovio (render)                      |
          |                                   |
     WebAudio (playback) <------ MusicXML ----+
          |
     IndexedDB (local project cache)
```

- **web-ui**: React (Vite), file drop, preview, align, edit (minimal), render via OSMD/Verovio, playback via WebAudio.
- **omr-service**: Node/Express wrapper that shells out to OMR (Audiveris). Pluggable provider interface (e.g., PlayScore/ScanScore via CLI or API where licenses permit).
- **musicxml-core**: Normalization passes (parts, measures, clefs), one‑line drum mapping, transpose utilities.
- **alignment-core**: Maintains mapping from raster coordinates → MusicXML element IDs. Enables side‑by‑side highlight syncing.
- **sound-engine**: MIDI/SF2 hooks (client) for simple playback.

## Data Model (high‑level)

- `Project` — id, created, updated, `assets[]`, `musicXml`, `alignment`, `userPrefs`.
- `Asset` — original file metadata + blob ref (local) or URL (server).
- `Alignment` — list of `{ bbox: [x1,y1,x2,y2], elementId }` pairs by page and measure.
- `UserPrefs` — staff type (one‑line/5‑line), beaming style, measure numbers, rehearsal marks, tempo, click subdivisions.

## API (initial draft)

- `POST /import` — upload file → `fileId`
- `POST /scan` — `{ fileId, options }` → `{ musicXml, report }`
- `POST /normalize` — `{ musicXml }` → `{ musicXml }`
- `POST /export/pdf` — `{ musicXml }` → PDF (optional; client can also print SVG/Canvas)
- `GET /health` — readiness probe
