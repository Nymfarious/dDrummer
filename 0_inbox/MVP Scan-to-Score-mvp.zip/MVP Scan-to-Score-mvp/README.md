
# Scan‑to‑Score MVP (dDrummer module)

**Goal:** Upload a screenshot/PDF/image of sheet music → get a **clean, digital score** (MusicXML) with options for one‑line or five‑line staff, basic editing, playback, and export.

**Monorepo packages:**
- `web-ui` — React app (Vite) with upload, preview, side‑by‑side compare, clean‑copy rendering.
- `omr-service` — OMR microservice wrapper (Audiveris or pluggable). Accepts files, emits MusicXML.
- `musicxml-core` — TypeScript utilities to normalize/transform MusicXML (parts, measures, transposition, drum/one‑line mapping).
- `engraving-engine` — Client wrappers around OpenSheetMusicDisplay/Verovio.
- `alignment-core` — Alignment layer between source image coordinates and MusicXML elements.
- `sound-engine` — Basic WebAudio/MIDI playback with SoundFont hooks.

> Privacy‑first: files stay local by default (browser IndexedDB via `web-ui`); uploads to `omr-service` are explicit and user‑initiated.

## Quick Start (conceptual)

```bash
# 1) install workspace deps
pnpm install

# 2) run OMR microservice (requires Java + Audiveris; see omr-service/README.md)
pnpm --filter omr-service dev

# 3) run the web UI
pnpm --filter web-ui dev
```

## MVP Flow

1. **Upload** (PDF/PNG/JPG).
2. **Scan** via `omr-service` → MusicXML.
3. **Review & align** (side‑by‑side; fix meter/clef/staff type).
4. **Clean copy** (render digital engraving; basic edits).
5. **Export** MusicXML/MIDI/PDF + lightweight `project.json`.

---

Created 2025-09-04T05:06:46.852145Z
