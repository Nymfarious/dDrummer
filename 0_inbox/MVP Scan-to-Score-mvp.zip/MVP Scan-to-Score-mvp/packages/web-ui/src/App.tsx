
import React, { useState } from 'react'

export default function App() {
  const [file, setFile] = useState<File | null>(null)
  const [musicXml, setMusicXml] = useState<string>('')
  const [report, setReport] = useState<string>('')

  async function handleScan() {
    if (!file) return
    const fd = new FormData()
    fd.append('file', file)
    const res = await fetch('http://localhost:5050/scan', { method: 'POST', body: fd })
    const data = await res.json()
    setMusicXml(data.musicXml || '')
    setReport(JSON.stringify(data.report || {}, null, 2))
  }

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', margin: '2rem', lineHeight: 1.4 }}>
      <h1>Scan‑to‑Score (MVP)</h1>
      <p>Upload a PDF/PNG/JPG and turn it into MusicXML (server OMR placeholder).</p>

      <input
        type="file"
        accept=".pdf,.png,.jpg,.jpeg"
        onChange={(e) => setFile(e.target.files?.[0] ?? null)}
      />
      <button onClick={handleScan} disabled={!file} style={{ marginLeft: '0.5rem' }}>
        Scan
      </button>

      <h2>Report</h2>
      <pre style={{ background: '#f6f8fa', padding: '1rem', overflow: 'auto' }}>{report}</pre>

      <h2>MusicXML</h2>
      <textarea
        value={musicXml}
        onChange={(e) => setMusicXml(e.target.value)}
        rows={16}
        style={{ width: '100%' }}
      />
    </div>
  )
}
