
/**
 * OMR adapter interface.
 * Replace the stub with a call to your OMR engine (e.g., shell out to Audiveris).
 */

export interface OMRScanOptions {
  staffType?: 'one-line' | 'five-line'
  meterHint?: string
  clefHint?: string
}

export interface OMRScanResult {
  musicXml: string
  report?: Record<string, unknown>
}

export async function scanToMusicXml(filePath: string, opts: OMRScanOptions = {}): Promise<OMRScanResult> {
  // TODO: Integrate Audiveris or another OMR engine here.
  // For now, return a tiny MusicXML snippet as a placeholder.
  const musicXml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 3.1 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<score-partwise version="3.1">
  <part-list>
    <score-part id="P1">
      <part-name>Clean Copy</part-name>
    </score-part>
  </part-list>
  <part id="P1">
    <measure number="1">
      <attributes>
        <divisions>1</divisions>
        <key><fifths>0</fifths></key>
        <time><beats>4</beats><beat-type>4</beat-type></time>
        <clef><sign>G</sign><line>2</line></clef>
      </attributes>
      <note><pitch><step>C</step><octave>4</octave></pitch><duration>1</duration><type>quarter</type></note>
      <note><pitch><step>D</step><octave>4</octave></pitch><duration>1</duration><type>quarter</type></note>
      <note><pitch><step>E</step><octave>4</octave></pitch><duration>1</duration><type>quarter</type></note>
      <note><pitch><step>F</step><octave>4</octave></pitch><duration>1</duration><type>quarter</type></note>
    </measure>
  </part>
</score-partwise>`;
  return { musicXml, report: { engine: "stub", hints: opts } }
}
