
import express from 'express'
import cors from 'cors'
import multer from 'multer'
import { scanToMusicXml } from './omr.js'

const app = express()
app.use(cors())
const upload = multer({ dest: 'uploads/' })

app.get('/health', (_req, res) => res.json({ ok: true }))

app.post('/scan', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'file required' })
  try {
    const result = await scanToMusicXml(req.file.path, {})
    res.json(result)
  } catch (e) {
    console.error(e)
    res.status(500).json({ error: 'scan failed' })
  }
})

app.listen(5050, () => {
  console.log('omr-service listening on http://localhost:5050')
})
