
# OMR Service

This service exposes a simple HTTP API to convert uploaded images/PDFs into MusicXML
by delegating to an Optical Music Recognition (OMR) engine (e.g., Audiveris).

## Endpoints

- `POST /scan` — multipart upload `{ file }` → `{ musicXml, report }`

> The current implementation returns a placeholder MusicXML. Wire up your OMR in `omr.ts`.
