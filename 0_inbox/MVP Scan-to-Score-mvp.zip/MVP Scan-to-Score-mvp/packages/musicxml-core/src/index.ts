
export type StaffType = 'one-line' | 'five-line'

export interface NormalizeOptions {
  staffType?: StaffType
  forceTimeSig?: string
  measureNumbers?: boolean
}

export function normalizeMusicXml(xml: string, _opts: NormalizeOptions = {}): string {
  // TODO: real XML transforms: parts, clefs, staff details, beaming, drum mapping
  return xml
}

export function transposeMusicXml(xml: string, semitones: number): string {
  // TODO: insert <transpose> or shift pitches
  void semitones
  return xml
}
