
export interface BBox { x1:number; y1:number; x2:number; y2:number }
export interface AlignmentLink {
  page: number
  bbox: BBox
  elementId: string // from MusicXML (e.g., measure or note ID)
}
export interface AlignmentMap {
  links: AlignmentLink[]
}

export function createAlignment(): AlignmentMap {
  return { links: [] }
}
