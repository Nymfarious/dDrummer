
/**
 * Thin wrappers for OSMD/Verovio would live here (client-side ideally).
 * This package can export shared types and helpers for rendering configuration.
 */

export interface RenderOptions {
  zoom?: number
  pageWidth?: number
  pageHeight?: number
}

export function planLayout(_musicXml: string, _opts: RenderOptions = {}) {
  // TODO: return bounding boxes for measures/systems to help alignment overlay
  return []
}
