
export interface PlayOptions {
  tempo?: number
  swing?: number
}

export async function playMusicXml(_xml: string, _opts: PlayOptions = {}) {
  // TODO: parse MusicXML -> MIDI events -> WebAudio/Soundfont playback
}
